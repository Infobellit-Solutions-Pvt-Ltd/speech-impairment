from jiwer import wer

# Define the transcriptions
turbo_transcription = [
    "I get there by bus and it takes about 15 minutes. I've got a friend called Emma and I go with her on the bus. I like PE, I like running. Arts, OK",
    "I like playing with computers and with computers you can do a lot of things. I have got a program called Visual Basic and you can make programs on that. It is a professional programmer's guide. And I have got the internet on my computer. And what you do on the internet you can find out billions of information just by typing in a little thing. If you type in animals for instance, what you can do with animals is you can get lots of pictures of animals and information of animals just by typing in animals. And lots of websites and to do with animals. And what you can do as well is you can play computer games on the computer. But I don't play too many games on the computer because I use it for typing up my design voices sometimes because...",
    "I have six cousins on my dad's side of the family, but on my mum's side of the family, I have none. So when my auntie was taken pregnant two weeks ago, I was speechless. And I knew that I had a baby cousin and she said, well, I'm going to have it in nine months. And I'm really looking forward to it. My auntie used to have two dogs and a cat. But then she adopted a dog with three legs and she had to take it in a hotel with her. That wasn't allowed. And then she hid it in the bag. So when she went up in the elevator with other people, it said she had to bark. So she had to cough to set up the barking. So we're going to have a baby with the dog. So, I'm going to have a baby. I'm going to have a baby. I'm going to have a baby."
]

large_v3_transcription = [
    "I get there by bus and it takes about 15 minutes. I've got a friend called Emma and I go with her on the bus. I like PE, I like running, arts, okay.",
    "I like playing with computers and with computers you can do a lot of things. I have got a program called Visual Basic and you can make programs on that. It is a professional programmers guide. And I have got the internet on my computer. And what you do on the internet, you can find out billions of information just by typing in a little thing. If you type in animals for instance, what you can do with animals, you can get lots of pictures of animals and information of animals just by typing in animals. And lots of websites and to do with animals. And what you can do as well is you can play computer games on the computer. But I don't play too many games. Because I use it for typing up. My design voice is sometimes because of the computer",
    "I have six cousins on my dad's side of the family, but on my mum's side of the family I have none. So when my auntie was taken pregnant two weeks ago, I was speechless. I knew that I had a baby cousin and she said we're going to have it in nine months. I'm really looking forward"
]

# Calculate WER for each paragraph
wer_list = [wer(ref, hyp) for ref, hyp in zip(large_v3_transcription, turbo_transcription)]
wer_list
